-- Table to store command history
local command_history = {}

-- Define your function to run Lua code
local function run_lua_code(code)
    local func, err = loadstring(code)
    if func then
        local success, result = pcall(func)
        if success then
            return result
        else
            return "Error running code: " .. tostring(result)
        end
    else
        return "Error loading code: " .. tostring(err)
    end
end

-- Function to display command history
local function show_history()
    local history = table.concat(command_history, "\n")
    return history == "" and "No commands run yet." or history
end

-- Register a chat command to run Lua code
minetest.register_chatcommand("debugpanel", {
    params = "<code>",
    description = "Run a string of Lua code",
    privs = {server = true},
    func = function(name, param)
        -- Store command in history
        table.insert(command_history, param)
        
        -- Run the Lua code
        local result = run_lua_code(param)
        minetest.chat_send_player(name, "Result: " .. tostring(result))
        
        return true
    end,
})

-- Register a chat command to show command history
minetest.register_chatcommand("history", {
    description = "Show command history",
    privs = {server = true},
    func = function(name, param)
        local history = show_history()
        minetest.chat_send_player(name, "Command History:\n" .. history)
        return true
    end,
})

-- Register a chat command to clear command history
minetest.register_chatcommand("clearhistory", {
    description = "Clear command history",
    privs = {server = true},
    func = function(name, param)
        command_history = {}
        return true, "Command history cleared."
    end,
})
